 This ROM Hack of Diddy Kong Racing (USA) (En,Fr) (Rev 1) applies the Music Fix, Unlocks all Secret Characters with Magic Codes, and enables Magic Codes to work in Adventure and Adventure 2; for anyone who wants a more classic experience.

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:

All Magic and Debug Codes Available
All Magic Codes work in Adventure and Adventure 2
Secret Characters T.T. and Drumstick Unlocked
Music Plays in 3 and 4 Player Multiplayer Mode
__________________________________________________________________________________

All Magic and Debug Codes Available:
Normally a player would have to manually enter in each password to unlock a Magic Code to use. This patch changes that so that all Magic and Debug Codes are available. They are found in Options -> Magic Codes -> Code List

All Magic Codes work in Adventure and Adventure 2 Details:
Normally the majority of Magic Codes only work in multiplayer, this patch changes that and allows you to use all of the Magic Codes for both Adventure 1 and 2. 

Music Plays in 3 and 4 Player Multiplayer Mode Details:
Normally music doesn't play in multiplayer with 3 or 4 players. This patch changes that so music always plays. 
__________________________________________________________________________________

Magic Codes List Details:
Big Characters = Enlarges all racers (Does not impact speed/control)
Small Characters = Shrinks all racers (Does not impact speed/control)
Music Menu = Adds Music Test to Audio Menu
Start with 10 Bananas = Provides you with 10 Bananas at the start of each race
Horn Cheat = Vehicle horn is replaced by that racer’s voice
Display Credits = Credits will roll after you leave the menu
Disable Weapons = Removes all Balloons from races
Disable Bananas = Removes all Bananas from races
Bananas Reduce Speed = Collecting Bananas will slow your racer down
No Limit to Bananas = Allows you to collect more than 10 Bananas
All Balloons Are Red = Makes all Balloons Red (Red Balloons have missiles)
All Balloons Are Green = Makes all Balloons Green (Green Balloons have traps)
All Balloons Are Blue = Makes all Balloons Blue (Blue Balloons have speed boost)
All Balloons Are Yellow = Makes all Balloons Yellow (Yellow Balloons have shields)
All Balloons Are Rainbow = Makes all Balloons Rainbow (Rainbow Balloons have magnets)
Maximum Power Up = Balloons give fully upgraded items (Multi Missiles, Bubbles, Purple Boost, Lightning Shields, Mega Magnets)
Turn Off Zippers = Removes all Zippers (Speed Boosts) from races
Select Same Player = Allows up to Four Players to select and use the same character
Four Wheel Drive = Terrain does not affect driving speed
Two Player Adventure = Allows Co-Op in Adventure Mode
Ultimate AI = Increases Computer Player difficulty
Debug/Unused Codes Details:
Control TT = Toggle ON to have T.T. available in the character select screen.
Control Drumstick = Toggle ON to have Drumstick available in the character select screen.
Mirrored Tracks = Toggle ON to have all tracks mirrored. (Essentially Adventure 2)
High Speed Racing = This is essentially a duplicate of “No Limit to Bananas.” Setting it to ON does nothing. (High Speed Racing has been removed in v1.2 / v1.3 as it did nothing).
Print Coords = Displays Player One’s coordinates in the upper left corner of the screen.
Free Balloon = Each time you start Adventure Mode with this ON, a balloon will be added to the selected save file.
EPC Lock Up Display = If the game crashes, next time it’s booted up, it will display a crash report screen.
ROM Checksum = Displays a checksum of the ROM when enabled. (Once enabled, the screen will go black for a few seconds)
Please Note: The last 3 Debug Codes on the Magic Codes list have been removed in v1.1 as they were garbled text that did nothing. High Speed Racing has been removed in v1.2 / v1.3 as it did nothing. 
__________________________________________________________________________________

Some Gameplay Tips:
Starting Boost: Press the A button as soon as “Get Ready” fades from the screen and you will get a blue boost.
Faster Speed: While in a car tap the A button quickly and rhythmically to increase speed from 60 MPH to 70 MPH.
Bigger Boost: Just before you hit a zipper, release the A button, and you will get a boost that is equivalent to 3 Blue Balloons.
180 Turn: Reverse your car and then move the control stick at a downward angle (left or right) while holding R.

__________________________________________________________________________________

Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Diddy Kong Racing (USA) (En,Fr) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/

ROM / ISO Information:
Database match: Diddy Kong Racing (USA) (En,Fr) (Rev 1)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 6D96743D46F8C0CD0EDB0EC5600B003C89B93755
File/ROM CRC32: 5ACCA298