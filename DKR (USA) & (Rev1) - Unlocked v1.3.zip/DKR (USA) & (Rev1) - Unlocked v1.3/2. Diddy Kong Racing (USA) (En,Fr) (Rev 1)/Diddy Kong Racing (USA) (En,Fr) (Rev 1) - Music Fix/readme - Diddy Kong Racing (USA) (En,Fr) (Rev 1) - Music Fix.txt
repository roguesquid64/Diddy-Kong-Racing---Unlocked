This ROM Hack of Diddy Kong Racing (USA) (En,Fr) (Rev 1) does not unlock anything and only enables music to always play in multiplayer with 3 or 4 players. 

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:
Music Plays in 3 and 4 Player Multiplayer Mode
Normally music doesn't play in multiplayer with 3 or 4 players. This patch changes that so music always plays. 
__________________________________________________________________________________

Some Gameplay Tips:
Starting Boost: Press the A button as soon as “Get Ready” fades from the screen and you will get a blue boost.
Faster Speed: While in a car tap the A button quickly and rhythmically to increase speed from 60 MPH to 70 MPH.
Bigger Boost: Just before you hit a zipper, release the A button, and you will get a boost that is equivalent to 3 Blue Balloons.
180 Turn: Reverse your car and then move the control stick at a downward angle (left or right) while holding R.

__________________________________________________________________________________

Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Diddy Kong Racing (USA) (En,Fr) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/

ROM / ISO Information:
Database match: Diddy Kong Racing (USA) (En,Fr) (Rev 1)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 6D96743D46F8C0CD0EDB0EC5600B003C89B93755
File/ROM CRC32: 5ACCA298