This ROM Hack of Diddy Kong Racing Unlocks all Courses, Vehicles, Collectibles, Bonus Content, Debug Codes, and adds some Quality-of-Life Updates.

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:

Adventure 2 Available
All Magic and Debug Codes Available
All Magic Codes work in Adventure and Adventure 2
Secret Characters T.T. and Drumstick Unlocked
Music Plays in 3 and 4 Player Multiplayer Mode
All Courses Available in Multiplayer (Race Tracks/Cups/Challenge Areas)
All Vehicles Available in Multiplayer
Use Any Vehicle on Any Race Track in Multiplayer (Car/Hovercraft/Plane)
Drive Fast through Water in Car (See details below on how to activate)
Enter Any World, Race, Boss, and Challenge Area, in Adventure and Adventure 2 (Regardless of how many balloons or keys you have)
All Four T.T. Amulets and Wizpig Amulets Unlocked (See details below on how to enable)
All 4 Secret Gold Keys Unlocked (See details below on how to enable)
All 5 Gold Trophies Unlocked (See details below on how to enable)
All 3 of Taj's Challenges Complete


__________________________________________________________________________________
Adventure 2 Available Details:
Normally Adventure 2 is only available after you defeat Wizpig for the second time in Adventure Mode. This patch changes that so Adventure 2 (Mirror Mode) is available at the start. 

All Magic and Debug Codes Available:
Normally a player would have to manually enter in each password to unlock a Magic Code to use. This patch changes that so that all Magic and Debug Codes are available. They are found in Options -> Magic Codes -> Code List

All Magic Codes work in Adventure and Adventure 2 Details:
Normally the majority of Magic Codes only work in multiplayer, this patch changes that and allows you to use all of the Magic Codes for both Adventure 1 and 2. 

Music Plays in 3 and 4 Player Multiplayer Mode Details:
Normally music doesn't play in multiplayer with 3 or 4 players. This patch changes that so music always plays. 

Use Any Vehicle on Any Race Track in Multiplayer Details:
You can now use any vehicle on any race track! Please note: There is a small bug in Pirate Lagoon when using the Plane in 1 Player Mode. The camera can get stuck at the starting line and not begin the race. You must press A as soon as the level loads and it will then spawn your character and begin the race. This issue only occurs in 1 Player Mode on this track with the plane. If it doesn't start the race for you simply Press Start, Restart the Race and Press A Repeatedly as the screen loads and it will work. 

Drive Fast through Water in Car Details:
At the Title screen hold L on your N64 controller and then press Start. Continue to hold L until the Character Select Screen loads. Enabling this will allow you to drive up to 150mph in the water with your car. This will allow you to defeat the first Wizpig easily even if you fall off the track, as well as race on water only courses. You must enable this at the Title Screen before you load up the rest of the game. If you begin the game normally but later want to enable the ability to drive fast through water simply restart the ROM.  

Enter Any World, Race, Boss, and Challenge Area, in Adventure and Adventure 2 Details:
You may enter Dino Domain, Snowflake Mountain, Sherbet Island, Dragon Forest and their respective race tracks, challenge areas and bosses with no balloons or keys. The set of four golden secret keys will still be available to collect in each of their respective race tracks. Winning the first race against a Word's Boss will grant you access to the Silver Coin Challenges. You must complete the Silver Coin Challenges to access each Boss's second race. The cutscene of the boss's doors opening will still trigger after you collect your 4th and 8th balloon in that world. To access Future Fun Land you will need the Wizpig Amulets and Four Trophies. Please read below on how to access the Amulets and Trophies early. You will still need all 47 balloons and T.T. Amulets to open the door to the final race against Wizpig in Future Fun Land.

All Four T.T. Amulets and Wizpig Amulets Unlocked Details:
Press and hold D-Pad Right when entering an area (such as Dragon Forest or the main hub) and you will unlock all Four pieces of both T.T. and Wizpig Amulets. Having all four Wizpig Amulets will trigger a cutscene on Timber's Island and allow you to face Wizpig early. The Four T.T. Amulets are needed to unlock the final race against Wizpig in Future Fun Land.

All 4 Secret Gold Keys Unlocked Details:
Press and hold D-Pad Left when entering an area (such as Snowflake Mountain) and you will unlock the set of four golden secret keys. Having all four keys will trigger a cutscene in each of their worlds of the Challenge Door being unlocked. 

All 5 Gold Trophies Unlocked  Details:
Press and hold D-Pad Up when entering an area (such as Dino Domain), and you will unlock the first 4 gold trophies. After you defeat Wizpig in the first race there will be a cutscene of the characters celebrating at the beach that Wizpig rudely interrupts. After Wizpig flies away, drive your vehicle into the billboard on the beach that shows the four trophies. This will trigger a cutscene of your character boarding a rocket ship to fly into outer space. You may press and hold Down on the D-Pad during the rocket scene or later when teleporting to/from Future Fun Land. Holding Down on the D-Pad will unlock the 5th and final gold trophy, as well as remove the billboard on the beach. 

All 3 of Taj's Challenges Complete Details:
Upon first starting your game you will notice 3 additional balloons floating around you in the main hub world. These are the balloons that Taj rewards you for completing his 3 races. You may still challenge Taj to each of these races (car, hovercraft, plane) if you would like. Simply honk your horn to get Taj to come up to you, or bonk him with your vehicle. 
__________________________________________________________________________________

Magic Codes List Details:
Big Characters = Enlarges all racers (Does not impact speed/control)
Small Characters = Shrinks all racers (Does not impact speed/control)
Music Menu = Adds Music Test to Audio Menu
Start with 10 Bananas = Provides you with 10 Bananas at the start of each race
Horn Cheat = Vehicle horn is replaced by that racer’s voice
Display Credits = Credits will roll after you leave the menu
Disable Weapons = Removes all Balloons from races
Disable Bananas = Removes all Bananas from races
Bananas Reduce Speed = Collecting Bananas will slow your racer down
No Limit to Bananas = Allows you to collect more than 10 Bananas
All Balloons Are Red = Makes all Balloons Red (Red Balloons have missiles)
All Balloons Are Green = Makes all Balloons Green (Green Balloons have traps)
All Balloons Are Blue = Makes all Balloons Blue (Blue Balloons have speed boost)
All Balloons Are Yellow = Makes all Balloons Yellow (Yellow Balloons have shields)
All Balloons Are Rainbow = Makes all Balloons Rainbow (Rainbow Balloons have magnets)
Maximum Power Up = Balloons give fully upgraded items (Multi Missiles, Bubbles, Purple Boost, Lightning Shields, Mega Magnets)
Turn Off Zippers = Removes all Zippers (Speed Boosts) from races
Select Same Player = Allows up to Four Players to select and use the same character
Four Wheel Drive = Terrain does not affect driving speed
Two Player Adventure = Allows Co-Op in Adventure Mode
Ultimate AI = Increases Computer Player difficulty
Debug/Unused Codes Details:
Control TT = Toggle ON to have T.T. available in the character select screen.
Control Drumstick = Toggle ON to have Drumstick available in the character select screen.
Mirrored Tracks = Toggle ON to have all tracks mirrored. (Essentially Adventure 2)
High Speed Racing = This is essentially a duplicate of “No Limit to Bananas.” Setting it to ON does nothing. (High Speed Racing has been removed in v1.2 / v1.3 as it did nothing).
Print Coords = Displays Player One’s coordinates in the upper left corner of the screen.
Free Balloon = Each time you start Adventure Mode with this ON, a balloon will be added to the selected save file.
EPC Lock Up Display = If the game crashes, next time it’s booted up, it will display a crash report screen.
ROM Checksum = Displays a checksum of the ROM when enabled. (Once enabled, the screen will go black for a few seconds)
Please Note: The last 3 Debug Codes on the Magic Codes list have been removed in v1.1 as they were garbled text that did nothing. High Speed Racing has been removed in v1.2 / v1.3 as it did nothing. 
__________________________________________________________________________________

Some Gameplay Tips:
Starting Boost: Press the A button as soon as “Get Ready” fades from the screen and you will get a blue boost.
Faster Speed: While in a car tap the A button quickly and rhythmically to increase speed from 60 MPH to 70 MPH.
Bigger Boost: Just before you hit a zipper, release the A button, and you will get a boost that is equivalent to 3 Blue Balloons.
180 Turn: Reverse your car and then move the control stick at a downward angle (left or right) while holding R.

__________________________________________________________________________________

Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Diddy Kong Racing (USA) (En,Fr) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/

ROM / ISO Information:
Database match: Diddy Kong Racing (USA) (En,Fr)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 0CB115D8716DBBC2922FDA38E533B9FE63BB9670
File/ROM CRC32: EB759206